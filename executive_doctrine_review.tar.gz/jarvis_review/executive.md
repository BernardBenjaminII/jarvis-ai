Who has authority?
